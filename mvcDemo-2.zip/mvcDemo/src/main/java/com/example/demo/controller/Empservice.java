package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Empservice {
	@Autowired
	Emprepo repo;
	
	public void saveemp(Employee emp)
	{
		repo.save(emp);
	}
	public List<Employee> listemp(Employee emp)
	{
		List<Employee> list=repo.findAll();
		return list;
	}

}
