package com.springexample1.Car.cardemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springexample1.car.Manufacturer;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 ApplicationContext context= new AnnotationConfigApplicationContext(CanConfig.class);
         Manufacturer manu=context.getBean("manufacturer", Manufacturer.class);
         manu.about();
        
    }
}
