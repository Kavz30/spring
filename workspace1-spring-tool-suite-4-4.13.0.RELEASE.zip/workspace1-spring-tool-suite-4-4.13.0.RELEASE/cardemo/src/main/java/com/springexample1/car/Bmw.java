package com.springexample1.car;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
public class Bmw extends Car{
   @Override
   public void demo()
   {
	   System.out.println("BMW car");
   }
}
