package com.springexample1.car;

public class Maruti extends Car{
   
	@Override
	public void demo()
	{
		System.out.println("Maruthi car");
	}
}
