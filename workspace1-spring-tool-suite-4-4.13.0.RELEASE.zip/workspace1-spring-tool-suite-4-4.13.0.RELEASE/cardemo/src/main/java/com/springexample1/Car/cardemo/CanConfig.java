package com.springexample1.Car.cardemo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.springexample1.car")
public class CanConfig {

}
