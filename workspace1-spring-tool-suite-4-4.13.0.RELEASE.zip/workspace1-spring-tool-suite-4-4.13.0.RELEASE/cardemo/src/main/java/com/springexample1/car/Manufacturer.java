package com.springexample1.car;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Manufacturer {
	
	@Autowired
	Car car;
	
	public void about()
	{
		car.demo();
		car.music();
	}

}
