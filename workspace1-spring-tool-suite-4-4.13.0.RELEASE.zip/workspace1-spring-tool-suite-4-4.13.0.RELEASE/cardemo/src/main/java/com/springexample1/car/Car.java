package com.springexample1.car;

import org.springframework.stereotype.Component;

@Component
public class Car {
	public void demo()
	{
		
	}
	public void music()
	{
		System.out.println("Music is playing");
	}

}
