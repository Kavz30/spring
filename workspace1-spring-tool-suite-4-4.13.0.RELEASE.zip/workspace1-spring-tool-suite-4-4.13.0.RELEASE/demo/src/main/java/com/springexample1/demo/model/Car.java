package com.springexample1.demo.model;

import org.springframework.stereotype.Component;

@Component
public abstract class Car {
	public abstract void name();
}
