package com.springexample1.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springexample1.demo.model.Audi;
import com.springexample1.demo.model.Car;
import com.springexample1.demo.model.Hundai;
import com.springexample1.demo.model.Manufacture;

/**
 * Hello world!
 *
 */
public class App 
{
    
	public static void main( String[] args )
    {
        ApplicationContext context= new AnnotationConfigApplicationContext(CarConfig.class);
        Manufacture manu=context.getBean("manufacture", Manufacture.class);
        manu.details();
       
       
    }
}
