package com.springexample1.demo.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Manufacture {
	
	@Autowired
	@Qualifier("hundai")
	Car car;
	
	@Autowired
	@Qualifier("audi")
	Car c;
	
	
	public void details()
	{
	    car.name();
	    c.name();
	    
	}

}
