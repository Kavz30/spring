package com.springexample1.demo.model;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
public class Hundai extends Car{
	
	public void name()
	{
		System.out.println("Hundai car");
	}

}
