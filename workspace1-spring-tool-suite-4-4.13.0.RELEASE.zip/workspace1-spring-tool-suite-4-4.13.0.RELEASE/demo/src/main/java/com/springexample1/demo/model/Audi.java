package com.springexample1.demo.model;

import org.springframework.stereotype.Component;

@Component
public class Audi extends Car{

	@Override
	public void name() {
		System.out.println("Inside Audi");
		
		
	}

}
